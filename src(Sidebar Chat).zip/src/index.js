import React from 'react';
import ReactDOM from 'react-dom';
import './index.css'; // You can create this file or modify the existing one
import App from './App';

ReactDOM.render(<App />, document.getElementById('root'));
